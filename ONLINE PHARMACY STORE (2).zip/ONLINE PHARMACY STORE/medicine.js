let openshopping = document.querySelector('#carticon');
let closeshopping = document.querySelector('#back');
let body = document.querySelector('body');
openshopping.addEventListener('click', ()=>{
    body.classList.add('active');
})
closeshopping.addEventListener('click', ()=>{
    body.classList.remove('active');
})

const product =[
    {
        id:0,
        image: 'image/image1.jpg',
        description:'Head ache/Migraine',
        title: 'Coricidine',
        price:300,
    },
    {
        id:1,
        image: 'image/image1.jpg',
        description:'Head ache/Migraine',
        title: 'Coricidine',
        price:220,
    },
    {
        id:2,
        image: 'image/vitamins.jpeg',
        description:'Vitamin B12 ',
        title: 'Medicine',
        price:380,
    },
    {
        id:3,
        image: 'image/medicine.jpeg',
        description:'Loose Motion Tablets',
        title: 'Medicine',
        price:250,
    },
];
const categories = [...new Set(product.map((item)=> 
   {return item} ))]

   let i=0;
document.getElementById('root').innerHTML = categories.map((item)=>
{
    var {image, title, description, price} = item;
    return(
        `<div class='box'>
          <div class='img-box'>
             <img class='images' src=${image}></img>
          </div>

          <div class='bottom'>
             <h2>${title}</h2><br>
             <h1>${description}</h1><br>
             <h2>Rs. ${price}.00</h2><br> 
             <p>orem ipsum dolor sit amet consectetur adipisicing elit. Quam beatae, deleniti incidunt, veniam numquam sit itaque saepe esse ut aspernatur id, libero optio eveniet expedita. Asperiores accusantium odit tempora expedita?Eos necessitatibus delectus eius dolorum esse m</p><br> ` +
        "<button onclick = 'addtocart("+(i++)+")'> Add To Cart</button>"+
        `</div>
        </div>`
  
    )
}).join('')

var cart =[];

function addtocart(a)
{
    cart.push({...categories[a]});
    displaycart();
}
function delElement(a)
{
    cart.splice(a, 1);
    displaycart();
}

function displaycart(a)
{
   let j=0, total=0;
   document.getElementById("quantity").innerHTML=cart.length;
   if(cart.length==0){
    document.getElementById('cartitem').innerHTML = "Your cart is empty.Let's do some shopping!";
    document.getElementById("total").innerHTML = "$" + 0 + ".00";
   }
   else{
         document.getElementById("cartitem").innerHTML = cart.map ((items)=>
         {
            var {image, title , price} = items;
            total = total+price;
            document.getElementById("total").innerHTML = "Rs" + total + ".00";
            return(
                `<div class='cart-item'>
                <div class ='row-img'>
                 <img class = 'rowimg' src=${image}>
                 </div>
                 <div><p style = 'font-size:12px;'>${title}</p></div>
                <div> <h2 style='font-size:15px;'>Rs. ${price}.00</h2></div>`+
                 "<div><i class='fa-solid fa-trash' onclick='delElement("+ (j++) +")'></i></div></div>"
            );
         }).join('');
   }
}



// document.getElementById('searchBar').addEventListener('keyup', (e)=>{
//      const searchData = e.target.value.toLowerCase();
//    const filterData = categories.filter((item)=>{
//              return(
//              item.title.toLocaleLowerCase().includes(searchData)
//          )
//      })
//      displayItem(filterData)
//  })
//    const displayItem = (items)=>{
//     document.getElementById('root').innerHTML = categories.map((item)=>{
//         var {image, title, description, price} = item;
//         return(
//             `<div class='box'>
//               <div class='img-box'>
//                  <img class='images' src=${image}></img>
//               </div>
    
//               <div class='bottom'>
//                  <h2>${title}</h2><br>
//                  <h1>${description}</h1><br>
//                  <h2>Rs. ${price}.00</h2><br> 
//                  <p>orem ipsum dolor sit amet consectetur adipisicing elit. Quam beatae, deleniti incidunt, veniam numquam sit itaque saepe esse ut aspernatur id, libero optio eveniet expedita. Asperiores accusantium odit tempora expedita?Eos necessitatibus delectus eius dolorum esse m</p><br> ` +
//             "<button onclick = 'addtocart("+(i++)+")'> Add To Cart</button>"+
//             `</div>
//             </div>`
//         )
//     }).join('')
//    };
//   displayItem(categories);-->