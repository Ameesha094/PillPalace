const product =[
    {
        id:0,
        image:'image/medicine.jpeg',
        title: 'medicine',
        description:'wzxecrvtbynumi',
        price: 120,
    },
    {
        id:1,
        image:'image/medicine.jpeg',
        title: 'medicine',
        description:'wzxecrvtbynumi',
        price: 120,
    },
    {
        id:2,
        image:'image/medicine.jpeg',
        title: 'medicine',
        description:'wzxecrvtbynumi',
        price: 120,
    },
    {
        id:3,
        image:'image/medicine.jpeg',
        title: 'medicine',
        description:'wzxecrvtbynumi',
        price: 120,
    },
    {
        id:4,
        image:'image/medicine.jpeg',
        title: 'medicine',
        description:'wzxecrvtbynumi',
        price: 120,
    }
];
const categories = [...new Set(product.map((item)=>
{
    return item
}))]
let i=0;
document.getElementById('page').innerHTML = categories.map((item)=>
{
    var {image, title, description, price} = item;
    return(
        `<div class =  'box'>
        <div class='img-box'>
        <img class='images' src=${image}></img>
        </div>
        <div class='bottom'>
        <p> ${title}</p>
        <h2>$ ${price}.00</h2>
        <p> ${description}</p> `+
        "<button onclick='addtocart("+(i++)+")'>Add to cart</button>"+
        `</div>
        </div>`
    )
}).join('')


var cart =[];
function addtocart(a){
    cart.push({...categories[a]});
    displaycart();
}



function displaycart(a){
    let j=0;
    if(cart.length==0){
        document.getElementById('cartitem').innerHTML = "cart os empty";
    }
    else{
        document.getElementById("cartitem").innerHTML=cart.map((items)=>
    {
        var {image, title,price} = items;
        return(
            `<div class='cart-item'>
            <div class = 'row-img'>
            <img class = 'rowing' src=${image}>
            </div>
            <p style = font-size:12px;'>${title}</p>
            <p style = font-size:12px;'>${description}</p> `+
            "<i class = 'fa-solid fa-trash' onclick='delElement("+(j++)+")'></i></div>"
        )
    }).join('');
    }
}